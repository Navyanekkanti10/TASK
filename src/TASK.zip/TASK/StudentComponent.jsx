// StudentComponent.js
import React from 'react';
import './Widget.css';

const StudentComponent = () => {
  return (
    <div className="widget">
      <h2>Students</h2>
      {/* Add your student-related content here */}
    </div>
  );
};

export default StudentComponent;
