import React from 'react';
import './Navbar.css';
const Navbar = () => {
  return (
    <div>
    <nav className="navbar">
      <h1>Navbar</h1>
    </nav>
    </div>
  );
}
export default Navbar;