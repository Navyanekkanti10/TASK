// TeacherComponent.js
import React from 'react';
import './Widget.css';

const TeacherComponent = () => {
  return (
    <div className="widget">
      <h2>Teachers</h2>
      {  }
    </div>
  );
};

export default TeacherComponent;
