// EventComponent.js
import React from 'react';
import './Widget.css';

const EventComponent = () => {
  return (
    <div className="widget">
      <h2>Events</h2>
      {/* Add your event-related content here */}
    </div>
  );
};

export default EventComponent;
